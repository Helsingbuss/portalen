// src/lib/sendMail.ts
import { Resend } from "resend";
import { readMailEnv, makeResendOrThrow } from "./mailEnv";
import { buildAdminOfferLink, buildOfferPublicLink } from "@/lib/offerToken";
import { renderOfferEmail } from "./mailTemplates";

export type SendOfferParams = {
  offerId: string;
  offerNumber?: string;

  // mottagare
  customerEmail?: string;
  customerName?: string;
  adminTo?: string;

  // prim�r resa
  from?: string; to?: string; date?: string; time?: string;
  via?: string | null; stop?: string | null;
  passengers?: number;

  // retur
  return_from?: string; return_to?: string; return_date?: string; return_time?: string;

  notes?: string | null;
};

export async function sendOfferMail(p: SendOfferParams) {
  const env = readMailEnv();
  const resend = makeResendOrThrow();

  // V�lj �to� (forceTo f�r fels�kning)
  const adminTo = env.forceTo || p.adminTo || env.offersInbox;
  const custTo  = env.forceTo || p.customerEmail;

  // L�nkar i mejlen
  const adminUrl = buildAdminOfferLink(p.offerId, p.offerNumber || "");
  const custUrl  = buildOfferPublicLink(p.offerId, p.offerNumber || "");

  // Rendera HTML via dina mallar
  const rendered = renderOfferEmail({
    offer: {
      id: p.offerId,
      number: p.offerNumber,
      from: p.from, to: p.to, date: p.date, time: p.time,
      via: p.via ?? undefined, stop: p.stop ?? undefined,
      passengers: p.passengers,
      return_from: p.return_from, return_to: p.return_to,
      return_date: p.return_date, return_time: p.return_time,
      notes: p.notes ?? undefined,
    },
    adminUrl, customerUrl: custUrl,
    customerName: p.customerName,
  });

  // Dev utan nyckel ? simulera utskick
  if (!env.hasKey && !env.isProd) {
    console.warn("[mail] RESEND_API_KEY saknas i dev � simulerar skickat.");
    console.log("[mail] Admin skulle f�tt:", adminTo);
    if (custTo) console.log("[mail] Kund skulle f�tt:", custTo);
    return { ok: true, simulated: true };
  }

  const tags = [{ name: "app", value: "helsingbuss-portal" }];

  // 1) admin
  const adminResp = await resend.emails.send({
    from: env.from,
    to: adminTo,
    subject: rendered.subjectForAdmin,
    html: rendered.htmlForAdmin,
    reply_to: env.replyTo,
    bcc: env.bccAll.length ? env.bccAll : undefined,
    tags,
  });
  console.log("[mail] admin send result:", adminResp?.id || adminResp);

  // 2) kund (om angiven)
  let customerId: string | undefined = undefined;
  if (custTo) {
    const custResp = await resend.emails.send({
      from: env.from,
      to: custTo,
      subject: rendered.subjectForCustomer,
      html: rendered.htmlForCustomer,
      reply_to: env.replyTo,
      tags,
    });
    customerId = (custResp as any)?.id;
    console.log("[mail] customer send result:", custResp?.id || custResp);
  }

  return { ok: true, adminId: (adminResp as any)?.id, customerId };
}

// Kvitto till kund n�r de skickar in offert
export async function sendCustomerReceipt(opts: {
  to: string; offerId: string; offerNumber?: string; customerName?: string;
}) {
  const env = readMailEnv();
  const resend = makeResendOrThrow();

  const url = buildOfferPublicLink(opts.offerId, opts.offerNumber || "");
  const html = `<p>Hej${opts.customerName ? " " + opts.customerName : ""}!</p>
<p>Tack f�r din offertf�rfr�gan. Du kan f�lja �rendet h�r:</p>
<p><a href="${url}">${url}</a></p>`;

  if (!env.hasKey && !env.isProd) {
    console.warn("[mail] (receipt) saknar nyckel i dev � simulerar.");
    return { ok: true, simulated: true };
  }

  const resp = await resend.emails.send({
    from: env.from,
    to: env.forceTo || opts.to,
    subject: `Vi har mottagit din offertf�rfr�gan`,
    html,
    reply_to: env.replyTo,
  });
  console.log("[mail] receipt send result:", (resp as any)?.id || resp);
  return { ok: true, id: (resp as any)?.id };
}
