﻿// src/pages/api/debug/resend-send.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { Resend } from "resend";
export const config = { runtime: "nodejs" };


type Ok = { ok: true; id?: string; from: string; to: string | string[]; subject: string; raw?: any };
type Err = { ok: false; error: string; raw?: any };

const RESEND_API_KEY = process.env.RESEND_API_KEY || "";
const MAIL_FROM      = process.env.MAIL_FROM || process.env.EMAIL_FROM || "Helsingbuss <info@helsingbuss.se>";
const REPLY_TO       = process.env.EMAIL_REPLY_TO || "";

export default async function handler(req: NextApiRequest, res: NextApiResponse<Ok | Err>) {
  try {
    if (req.method !== "POST") {
      return res.status(405).json({ ok: false, error: "Method not allowed" });
    }
    if (!RESEND_API_KEY) {
      return res.status(500).json({ ok: false, error: "RESEND_API_KEY saknas i miljön" });
    }

    const { to, subject, name, text, html } = (typeof req.body === "string" ? JSON.parse(req.body) : req.body) || {};
    if (!to)      return res.status(400).json({ ok: false, error: "`to` krävs" });
    if (!subject) return res.status(400).json({ ok: false, error: "`subject` krävs" });

    const resend = new Resend(RESEND_API_KEY);

    const safeName = (name && String(name).trim()) || "Helsingbuss";
    const plain    = (text && String(text)) || "Testmeddelande från debug-endpointen.";
    const bodyHtml =
      html ||
      `<!doctype html><meta charset="utf-8">
      <div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">
        <h1 style="margin:0 0 8px 0;color:#194c66">Debug-mail</h1>
        <p>Hej ${safeName}!</p>
        <p>${plain}</p>
        <hr style="border:none;border-top:1px solid #eee;margin:16px 0">
        <small style="color:#6b7280">Skickat via /api/debug/resend-send</small>
      </div>`;

    const result = await resend.emails.send({
      from: MAIL_FROM,
      to,
      subject,
      html: bodyHtml,
      text: plain,
      reply_to: REPLY_TO || undefined,
    });

    if (result.error) {
      return res.status(400).json({ ok: false, error: result.error.message || "Okänt Resend-fel", raw: result });
    }

    return res.status(200).json({
      ok: true,
      id: result.data?.id,
      from: MAIL_FROM,
      to,
      subject,
      raw: result,
    });
  } catch (e: any) {
    return res.status(500).json({ ok: false, error: e?.message || "Serverfel", raw: e });
  }
}

