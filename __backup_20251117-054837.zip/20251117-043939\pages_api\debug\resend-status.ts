// src/pages/api/debug/resend-status.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { Resend } from "resend";

type Ok = { ok: true; env: any; domains: any[] };
type Err = { ok: false; error: string };

export default async function handler(req: NextApiRequest, res: NextApiResponse<Ok | Err>) {
  try {
    const key = process.env.RESEND_API_KEY || "";
    const from = process.env.MAIL_FROM || process.env.EMAIL_FROM || "";
    const offersInbox = process.env.OFFERS_INBOX || "";
    const forceTo = process.env.MAIL_FORCE_TO || null;

    const env = {
      hasKey: !!key,
      keyPrefix: key ? key.slice(0, 8) : null,
      from,
      offersInbox,
      forceTo,
    };

    if (!key) {
      return res.status(200).json({ ok: true, env, domains: [] });
    }

    const resend = new Resend(key);
    const list: any = await resend.domains.list().catch(() => null);
    const domains = Array.isArray(list?.data) ? list.data : [];

    return res.status(200).json({ ok: true, env, domains });
  } catch (e: any) {
    return res.status(500).json({ ok: false, error: e?.message || "Serverfel" });
  }
}
